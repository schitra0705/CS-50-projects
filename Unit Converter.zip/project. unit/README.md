Unit Converter CLI App

Video Demo:  https://youtu.be/rKlBY6ipw08

Description

The Unit Converter CLI App is a command-line tool that allows users to convert values between different units in three major categories: length, weight, and temperature. The purpose of this project is to create a simple yet efficient solution for performing unit conversions without the need for a graphical interface. Users can input a value, specify the unit they are converting from and to, and receive the converted result instantly.

This project was created to simplify unit conversions, especially for students, travelers, and professionals who frequently need to switch between different measurement systems. By implementing this app, I aimed to improve my Python skills, particularly in handling command-line arguments, error management, and modular programming. Additionally, I wanted to demonstrate good software engineering practices by incorporating unit tests using pytest.

For example, a traveler might need to quickly convert kilometers to miles while driving in a foreign country, or a cook might need to convert ounces to grams when following an international recipe. This tool provides an easy and reliable way to perform such conversions directly from the terminal.

Features

1. Convert between different units

The app supports multiple unit conversions, including:

Length: Meters, kilometers, feet, and miles.

Weight: Kilograms, grams, pounds, and ounces.

Temperature: Celsius, Fahrenheit, and Kelvin.

Users can specify the category, input value, and units in a structured command format to get precise conversions.

2. Command-line interface for ease of use

Instead of relying on graphical interfaces, this application operates entirely via the command line, making it lightweight and efficient. Users can enter commands like:
                              python project.py weight 10 kg g

python project.py length 10 meters feet

This ensures that the tool is fast, accessible, and does not require additional dependencies beyond standard Python modules.

3. Error handling for invalid inputs

The app includes robust error handling to manage cases where:

The user provides an invalid unit name.

The user enters a non-numeric value where a number is expected.

The conversion is not logically possible (e.g., trying to convert kilograms to Celsius).

By handling these errors, the app ensures a smooth user experience.

4. Modular and maintainable code

The project is structured using separate functions for different conversion categories, making the code modular and easy to maintain. Each function is responsible for a specific conversion type, which enhances code readability and scalability.

5. Unit testing with pytest

To ensure accuracy and reliability, the app includes automated tests using pytest. These tests verify that conversions return the expected values and catch any potential errors before deployment. Testing is crucial for maintaining code integrity and prevents unexpected bugs when modifying or extending the project.

File Structure

1. project.py

This is the main script that contains the implementation of:

convert_length(): Converts between meters, kilometers, feet, and miles.

convert_weight(): Converts between kilograms, grams, pounds, and ounces.

convert_temperature(): Converts between Celsius, Fahrenheit, and Kelvin.

main(): Handles command-line input using argparse, validates the inputs, and prints the conversion result.

2. test_project.py

This file contains unit tests for each conversion function. Using pytest, the script:

Validates that conversion functions return correct values.

Checks for correct handling of edge cases and invalid inputs.

By implementing automated tests, we ensure that the code works as expected and can be modified without introducing new errors.

Conclusion

This project was an excellent opportunity to apply Python programming, command-line interaction, and software testing in a practical setting. Throughout the development process, I improved my understanding of argument parsing, error handling, and modular programming.

Future Improvements

Add support for more unit categories (e.g., speed, volume, and currency conversion).

Implement a GUI version using Tkinter or PyQt for users who prefer graphical interfaces.

Allow users to define custom conversion formulas to handle specialized cases.

Improve the error messages to suggest correct input formats.

By continuously improving this tool, it can become a more comprehensive and widely-used utility for performing quick and accurate unit conversions.

## How to Use:
1. **Open your README file** using nano:
   ```sh
   nano README.md
