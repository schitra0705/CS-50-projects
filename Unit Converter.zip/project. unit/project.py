import argparse

def convert_length(value, from_unit, to_unit):
    """Convert length units."""
    length_units = {
        "m": 1, "km": 1000, "ft": 0.3048, "mile": 1609.34
    }

    from_unit, to_unit = from_unit.lower(), to_unit.lower()

    if from_unit not in length_units:
        raise ValueError(f"Invalid length unit: {from_unit}")
    if to_unit not in length_units:
        raise ValueError(f"Invalid length unit: {to_unit}")

    meters = value * length_units[from_unit]
    return meters / length_units[to_unit]

def convert_weight(value, from_unit, to_unit):
    """Convert weight units."""
    weight_units = {
        "kg": 1, "g": 0.001, "lb": 0.453592, "oz": 0.0283495
    }

    from_unit, to_unit = from_unit.lower(), to_unit.lower()

    if from_unit not in weight_units:
        raise ValueError(f"Invalid weight unit: {from_unit}")
    if to_unit not in weight_units:
        raise ValueError(f"Invalid weight unit: {to_unit}")

    kg = value * weight_units[from_unit]
    return kg / weight_units[to_unit]

def convert_temperature(value, from_unit, to_unit):
    """Convert temperature units."""
    from_unit, to_unit = from_unit.upper(), to_unit.upper()

    if from_unit == "C" and to_unit == "F":
        return (value * 9/5) + 32
    elif from_unit == "F" and to_unit == "C":
        return (value - 32) * 5/9
    elif from_unit == "C" and to_unit == "K":
        return value + 273.15
    elif from_unit == "K" and to_unit == "C":
        return value - 273.15
    elif from_unit == "F" and to_unit == "K":
        return (value - 32) * 5/9 + 273.15
    elif from_unit == "K" and to_unit == "F":
        return (value - 273.15) * 9/5 + 32
    else:
        raise ValueError(f"Invalid temperature unit: {from_unit} or {to_unit}")

def main():
    """Main function to handle CLI arguments."""
    parser = argparse.ArgumentParser(description="Unit Converter CLI")
    parser.add_argument("category", choices=["length", "weight", "temperature"], help="Conversion category")
    parser.add_argument("value", type=float, help="Value to convert")
    parser.add_argument("from_unit", help="Convert from unit")
    parser.add_argument("to_unit", help="Convert to unit")

    args = parser.parse_args()

    try:
        if args.category == "length":
            result = convert_length(args.value, args.from_unit, args.to_unit)
        elif args.category == "weight":
            result = convert_weight(args.value, args.from_unit, args.to_unit)
        elif args.category == "temperature":
            result = convert_temperature(args.value, args.from_unit, args.to_unit)

        print(f"✅ {args.value} {args.from_unit} = {result:.2f} {args.to_unit}")

    except ValueError as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
