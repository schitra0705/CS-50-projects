import pytest
from project import convert_length, convert_weight, convert_temperature

def test_convert_length():
    """Test length conversions."""
    assert convert_length(1, "km", "m") == 1000
    assert convert_length(10, "m", "ft") == pytest.approx(32.8084, rel=1e-3)
    assert convert_length(100, "mile", "km") == pytest.approx(160.934, rel=1e-3)

    # Test same-unit conversion
    assert convert_length(5, "m", "m") == 5

    # Test case insensitivity
    assert convert_length(1, "KM", "m") == 1000  # Uppercase input

def test_convert_weight():
    """Test weight conversions."""
    assert convert_weight(1, "kg", "g") == 1000
    assert convert_weight(5, "lb", "kg") == pytest.approx(2.26796, rel=1e-3)
    assert convert_weight(16, "oz", "lb") == 1  # 16 oz = 1 lb
    assert convert_weight(500, "g", "kg") == 0.5  # 500 g = 0.5 kg

    # Test case insensitivity
    assert convert_weight(1, "KG", "g") == 1000  # Uppercase input

def test_convert_temperature():
    """Test temperature conversions."""
    assert convert_temperature(0, "C", "F") == 32
    assert convert_temperature(100, "C", "K") == 373.15
    assert convert_temperature(32, "F", "C") == 0
    assert convert_temperature(273.15, "K", "C") == 0  # Kelvin to Celsius
    assert convert_temperature(212, "F", "K") == pytest.approx(373.15, rel=1e-3)  # Fahrenheit to Kelvin
    assert convert_temperature(0, "K", "F") == pytest.approx(-459.67, rel=1e-3)  # Kelvin to Fahrenheit

    # Test case insensitivity
    assert convert_temperature(100, "c", "k") == 373.15  # Lowercase input

def test_invalid_units():
    """Test invalid unit conversions."""
    with pytest.raises(ValueError, match="Invalid length unit"):
        convert_length(10, "meters", "ft")  # Invalid unit

    with pytest.raises(ValueError, match="Invalid weight unit"):
        convert_weight(1, "pounds", "kg")  # Invalid unit

    with pytest.raises(ValueError, match="Invalid temperature unit"):
        convert_temperature(100, "X", "C")  # Invalid unit

