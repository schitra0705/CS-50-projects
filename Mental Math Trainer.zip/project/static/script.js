document.addEventListener("DOMContentLoaded", () => {
    const answerInput = document.querySelector("input[name='answer']");
    const form = document.querySelector("form");
    const submitBtn = document.querySelector("button[type='submit']");

    // Autofocus on answer input
    if (answerInput) {
      answerInput.focus();
    }

    // Prevent double submission
    if (form && submitBtn) {
      form.addEventListener("submit", () => {
        submitBtn.disabled = true;
        submitBtn.innerText = "Submitting...";
      });
    }
  });
