# Mental Math Trainer
#### Video Demo:  <https://youtu.be/cL7OUIMkXOI>
#### Description:

Mental Math Trainer is a web-based interactive application designed to sharpen your arithmetic skills by challenging your mind with quick-fire mental math problems. Built using Python’s Flask framework for the backend, with HTML, CSS, and JavaScript on the frontend, this lightweight quiz app offers a fast and intuitive interface for learners of all levels. Whether you’re brushing up on your basics or trying to speed up your brain’s ability to do calculations on the fly, this app is a great companion.

The core idea behind Mental Math Trainer is to help users become more fluent with basic arithmetic operations—addition, subtraction, multiplication, and division—without relying on calculators or other external aids. By limiting the time available for each question, the application encourages users to think quickly, helping develop stronger reflexes in mathematical reasoning.

### How it works:

When the user opens the app, they are greeted with a clean homepage that offers a button to start the quiz. Clicking “Start” initializes a new session, and the user is taken through a set of 5 randomly generated arithmetic problems. Each problem presents two randomly selected numbers between 1 and 10, along with a randomly chosen arithmetic operator (+, -, *, or /). The questions are designed such that division problems always yield integer results, using floor division where necessary, so the answers stay intuitive and manageable without decimals.

Once a question is displayed, the user has exactly 10 seconds to input their answer before the timer runs out. If time expires, the app automatically submits the answer as “None” and proceeds to a feedback page. Whether the answer is correct or not, the user receives instant feedback: a message confirming if they were right or wrong, and the correct answer is shown for reinforcement. This feedback screen includes a “Next” button, allowing users to move on to the following question.

Throughout the quiz, the application keeps track of the user’s current score and question number using Flask’s session system. After all five questions are completed, a result page summarizes the final score and provides an option to reset and try again.
### Features:

- 🧠 Real-time mental math training
- ⏱️ Countdown timer for each question
- ✅ Instant answer feedback
- 📊 Final score summary
- 🎨 Simple and clean UI with styling via CSS

### Technology used:
- Python 3 / Flask – Web framework for handling routing, sessions, and server logic.

- HTML5 – Markup structure for each page.

- CSS3 – Custom styles for layout and visual design.

- JavaScript – Countdown timer logic for each quiz question.

- Jinja2 – Templating engine used to dynamically render content from Flask to HTML.

### File Overview:

- `app.py` – Main Flask backend handling routes and logic
- `templates/` – HTML files (`index.html`, `quiz.html`, `feedback.html`, `result.html`) rendered by Flask
- `static/` – Includes `styles.css` for styling and `script.js` for countdown logic
- `requirements.txt` – Python dependencies (only Flask required)
- `README.md` – Project documentation


### How to Run:
1. Clone the repository or download the project files.

2. Ensure Python 3 is installed.

3. Open a terminal and navigate to the project directory.

4. Install dependencies:
pip install flask

5. IN TERMINAL RUN: flask run

6. Open your browser and go to http://127.0.0.1:5000/ to use the app.

This project was built as the final project for CS50’s Introduction to Computer Science, and it demonstrates proficiency in both backend and frontend development, including routing, user session management, template rendering, and DOM manipulation using JavaScript.



