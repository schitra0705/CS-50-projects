from flask import Flask, render_template, request, redirect, session, url_for
import random

app = Flask(__name__)
app.secret_key = "super_secret_key"

operations = {
    "+": lambda x, y: x + y,
    "-": lambda x, y: x - y,
    "*": lambda x, y: x * y,
    "/": lambda x, y: x // y if y != 0 else 0
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/start", methods=["POST"])
def start():
    session["score"] = 0
    session["question_num"] = 0
    session["total_questions"] = 5
    return redirect(url_for("quiz"))

@app.route("/quiz")
def quiz():
    if session["question_num"] >= session["total_questions"]:
        return redirect("/result")

    x = random.randint(1, 10)
    y = random.randint(1, 10)
    symbol = random.choice(list(operations.keys()))

    if symbol == "/" and y == 0:
        y = random.randint(1, 10)

    correct = operations[symbol](x, y)

    session["x"] = x
    session["y"] = y
    session["symbol"] = symbol
    session["correct"] = correct

    return render_template("quiz.html", x=x, y=y, symbol=symbol, qn=session["question_num"] + 1, score=session["score"])

@app.route("/answer", methods=["POST"])
def answer():
    user_answer = request.form.get("answer")

    try:
        user_answer = int(user_answer)
    except ValueError:
        user_answer = None

    correct = session["correct"]
    is_correct = user_answer == correct

    # Save result in session
    session["is_correct"] = is_correct
    session["user_answer"] = user_answer

    if is_correct:
        session["score"] += 1

    return redirect("/feedback")


@app.route("/feedback")
def feedback():
    return render_template("feedback.html",
                           x=session["x"],
                           y=session["y"],
                           symbol=session["symbol"],
                           user_answer=session["user_answer"],
                           correct=session["correct"],
                           is_correct=session["is_correct"],
                           score=session["score"],
                           qn=session["question_num"] + 1,
                           total=session["total_questions"])

@app.route("/next", methods=["POST"])
def next():
    session["question_num"] += 1
    return redirect("/quiz")


@app.route("/result")
def result():
    return render_template("result.html", score=session["score"], total=session["total_questions"])

@app.route("/reset")
def reset():
    session.clear()
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
